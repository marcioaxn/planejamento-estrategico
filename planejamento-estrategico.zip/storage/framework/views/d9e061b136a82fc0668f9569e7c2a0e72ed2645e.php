<?php $attributes = $attributes->exceptProps(['active']); ?>
<?php foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$classes = ($active ?? false)
            ? 'bg-blue-800 block px-4 py-2 text-sm leading-5 text-white focus:outline-none focus:bg-gray-100 transition'
            : 'block px-4 py-2 text-sm leading-5 text-gray-700 hover:bg-indigo-100 focus:outline-none focus:bg-gray-100 transition';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>><?php echo e($slot); ?></a>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/vendor/jetstream/components/dropdown-link.blade.php ENDPATH**/ ?>