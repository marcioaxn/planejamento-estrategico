<a href="<?php echo date('Y'); ?>">
    <img src="<?php echo e(asset('img/brasaoRepublica_small.png')); ?>">
</a>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>