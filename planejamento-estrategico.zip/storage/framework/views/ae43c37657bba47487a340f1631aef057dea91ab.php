<div class="flex flex-wrap w-full text-lg md:text-sm pt-1 pb-3 pl-3 pr-3 rounded-md border-1 border-gray-100"
    style="font-size: 0.91rem!Important;">

    <?php if($this->indicador): ?>

        <div class="w-full md:w-1/1 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            <span class="font-bold text-lg"><?php $this->objetivoEstrategico->indicadores->count() > 1 ? print 'Indicadores' : print 'Indicador'; ?></span>

            <span>( <span class="text-sky-700"><?php echo e($this->objetivoEstrategico->indicadores->count()); ?></span> )</span>

            <br />

            <div wire:offline>
                You are now offline.
            </div>

            <div class="mt-1 mb-1 pt-1" wire:loading>
                <p><i class='fa fa-circle-notch fa-spin text-blue-600'></i> Carregando...</p>
            </div>
        </div>

        <div class="w-full md:w-1/1 border-b-2 border-gray-100 pt-1 pb-2 pl-1">

            <div
                class="grid grid-cols-1 sm:grid-cols-4 md:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-2 mt-0">

                <?php $contIndicador = 1; ?>

                <?php $__currentLoopData = $this->objetivoEstrategico->indicadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $contMes = 1;
                    $totalPrevisto = 0;
                    $totalRealizado = 0;
                    $temMeta = false;
                    ?>

                    <?php $__currentLoopData = $indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                            <?php

                            if ($this->ano == date('Y')) {
                                if ($evolucaoIndicador->num_mes <= $this->mesAnterior) {
                                    if ($indicador->bln_acumulado === 'Sim') {
                                        $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                        $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                    } else {
                                        if (isset($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->vlr_previsto) && $evolucaoIndicador->vlr_previsto != '') {
                                            $totalPrevisto = $evolucaoIndicador->vlr_previsto;
                                        }

                                        if (isset($evolucaoIndicador->vlr_realizado) && !is_null($evolucaoIndicador->vlr_realizado) && $evolucaoIndicador->vlr_realizado != '' && $evolucaoIndicador->vlr_realizado > 0) {
                                            $totalRealizado = $evolucaoIndicador->vlr_realizado;
                                        }
                                    }
                                }
                            } else {
                                if ($indicador->bln_acumulado === 'Sim') {
                                    $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                    $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                } else {
                                    if (isset($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->vlr_previsto) && $evolucaoIndicador->vlr_previsto != '') {
                                        $totalPrevisto = $evolucaoIndicador->vlr_previsto;
                                    }

                                    if (isset($evolucaoIndicador->vlr_realizado) && !is_null($evolucaoIndicador->vlr_realizado) && $evolucaoIndicador->vlr_realizado != '' && $evolucaoIndicador->vlr_realizado > 0) {
                                        $totalRealizado = $evolucaoIndicador->vlr_realizado;
                                    }
                                }
                            }

                            ?>

                            <?php $contMes = $contMes + 1;
                            $totalPrevisto > 0 ? ($temMeta = true) : ($temMeta = false); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $resultado = $this->calcularAcumuladoIndicador($indicador->cod_indicador, $this->anoSelecionado); ?>

                    <?php
                    if (array_key_exists('grau_de_satisfacao', $resultado)) {
                        ?>
                    <div class="pt-2 pb-1 pl-2 text-lg text-lef bg-white-500 text-<?php echo $resultado['grau_de_satisfacao']; ?>-<?php $resultado['grau_de_satisfacao'] != 'pink' ? print '600' : print '800'; ?> rounded-md border-2 border-gray-100 shadow cursor-pointer"
                        onclick="javascript: alterarIndicador('<?php print $indicador->cod_indicador; ?>');">

                        <?php is_null($this->cod_indicador) && $contIndicador == 1 ? print '<i class="fas fa-arrow-circle-right"></i>&nbsp;' : print ' &nbsp;'; ?><?php $indicador->cod_indicador == $this->cod_indicador ? print '<i class="fas fa-arrow-circle-right"></i>&nbsp;' : print ' &nbsp;'; ?><strong>&nbsp;<?php echo $indicador->nom_indicador; ?></strong>

                    </div>
                    <?php
                    $contIndicador++;
                    }
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <script>
                    function alterarIndicador(cod_indicador) {

                        window.livewire.find('<?php echo e($_instance->id); ?>').cod_indicador_selecionado = cod_indicador;

                    }
                </script>

            </div>

        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Descrição do Indicador: <strong><?php echo e($this->indicador->dsc_indicador); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Observações: <strong><?php echo $this->indicador->txt_observacao; ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Descrição da Meta: <strong><?php echo e($this->indicador->dsc_meta); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Atributos: <strong><?php echo e($this->indicador->dsc_atributos); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Referencial comparativo: <strong><?php echo e($this->indicador->dsc_referencial_comparativo); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Unidade de Medida: <strong><?php echo e($this->indicador->dsc_unidade_medida); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Indicador terá o resultado acumulado? <strong><?php echo e($this->indicador->bln_acumulado); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Tipo de Análise (Polaridade): <strong><?php echo e(tipoPolaridade($this->indicador->dsc_tipo)); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Período de medição: <strong><?php echo e($this->indicador->dsc_periodo_medicao); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Fonte: <strong><?php echo e($this->indicador->dsc_fonte); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">
            Fórmula do Indicador: <strong><?php echo nl2br($this->indicador->dsc_formula); ?></strong>
        </div>

        <div class="w-full md:w-2/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">

            <?php $__currentLoopData = $this->indicador->linhaBase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linhaBase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                Linha de base do ano de <strong><?php echo $linhaBase->num_ano; ?></strong> é
                <?php $this->indicador->dsc_unidade_medida === 'Dinheiro' ? print '%' : print ''; ?><strong><?php echo formatarValorConformeUnidadeMedida(
                    $this->indicador->dsc_unidade_medida,
                    'MYSQL',
                    'PTBR',
                    $linhaBase->num_linha_base,
                ); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?></strong>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="w-full md:w-6/6 border-b-2 border-gray-100 pt-2 pb-2 pl-1">

            <?php if($this->indicador->dsc_tipo === '+'): ?>
                <i class="fas fa-arrow-alt-circle-up text-lg"></i> <strong><?php echo tipoPolaridade($this->indicador->dsc_tipo); ?></strong>
                será para esse indicador que tem a meta prevista de
                <strong><?php echo e(formatarValorConformeUnidadeMedida($this->indicador->dsc_unidade_medida, 'MYSQL', 'PTBR', $this->metaAno)); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?></strong>
                para o ano de <?php echo $this->anoSelecionado; ?>.
            <?php endif; ?>

            <?php if($this->indicador->dsc_tipo === '-'): ?>
                <i class="fas fa-arrow-alt-circle-down text-lg"></i> <strong><?php echo tipoPolaridade($this->indicador->dsc_tipo); ?></strong>
                será para esse indicador que tem a meta prevista de
                <strong><?php echo e(formatarValorConformeUnidadeMedida($this->indicador->dsc_unidade_medida, 'MYSQL', 'PTBR', $this->metaAno)); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?></strong>
                para o ano de <?php echo $this->anoSelecionado; ?>.
            <?php endif; ?>

            <?php if($this->indicador->dsc_tipo === '='): ?>
                <i class="fas fa-equals text-lg"></i> <strong><?php echo tipoPolaridade($this->indicador->dsc_tipo); ?></strong> será para esse
                indicador que tem a meta prevista de
                <strong><?php echo e(formatarValorConformeUnidadeMedida($this->indicador->dsc_unidade_medida, 'MYSQL', 'PTBR', $this->metaAno)); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?></strong>
                para o ano de <?php echo $this->anoSelecionado; ?>.
            <?php endif; ?>

        </div>

        <div class="w-full md:w-1/1 border-b-2 border-gray-100 pt-2 pb-2 pl-1">

            <script type="text/javascript">
                function abrirFecharTabs(num_tab = '') {

                    for (i = 1; i <= 3; i++) {

                        // document.getElementById('divConteudoTab'+i).style.display = 'none';

                        $("#divConteudoTab" + i).fadeOut("fast");

                        $("#btnTab" + i).removeClass(
                            "inline-block py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-2 border-blue-600 active hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300"
                        );

                        $("#btnTab" + i).addClass(
                            "inline-block py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-2 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300"
                        );

                    }

                    $("#btnTab" + num_tab).addClass(
                        "inline-block py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-2 border-blue-600 active hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300"
                    );

                    setTimeout(function() {
                        $("#divConteudoTab" + num_tab).fadeIn("slow");
                    }, 66);

                }
            </script>

            <div class="mb-4 border-b border-gray-200 dark:border-gray-700">
                <ul class="flex flex-wrap -mb-px" id="myTab" data-tabs-toggle="#myTabContent" role="tablist">
                    <li class="mr-2" role="presentation">
                        <button id="btnTab1"
                            class="inline-block py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-4 border-blue-600 active hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300"
                            onclick="javascript: abrirFecharTabs('1');">Evolução mensal - Resumo</button>
                    </li>
                    <li role="presentation">
                        <button id="btnTab3"
                            class="inline-block py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-2 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300"
                            onclick="javascript: abrirFecharTabs('3');">Evolução mensal - Detalhamento</button>
                    </li>
                </ul>
            </div>

            
            <div id="divConteudoTab1" style="display: block;">

                <?php
                    $totalPrevisto = 0;
                    $totalRealizado = 0;
                ?>

                <div class=" flex flex-wrap -mx-3 mb-6">

                    <div class="w-full md:w-1/1 px-3 mb-6 md:mb-0 pt-3">

                        <div class="border-b border-gray-200 shadow rounded-md">

                            <div class="flex flex-col">

                                <div class="overflow-x-auto">

                                    <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">

                                        <div class="overflow-x-auto">

                                            
                                            <table class="min-w-full">
                                                <thead class="border-b">

                                                    <tr class="">

                                                        <th
                                                            class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                            <strong>Meta</strong>
                                                        </th>

                                                        <?php $contMes = 1; ?>

                                                        <?php $__currentLoopData = $this->indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                                                                <th
                                                                    class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                                    <strong><?php echo mesNumeralParaExtensoCurto($evolucaoIndicador->num_mes); ?></strong>
                                                                </th>

                                                                <?php $contMes = $contMes + 1; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($this->indicador->bln_acumulado == 'Sim'): ?>

                                                            <?php if($this->ano == date('Y')): ?>
                                                                <th
                                                                    class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                                    <strong>Acumulado até
                                                                        <?php echo mesNumeralParaExtensoCurto($this->mesAnterior); ?></strong>
                                                                </th>
                                                            <?php else: ?>
                                                                <th
                                                                    class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                                    <strong>Total</strong>
                                                                </th>
                                                            <?php endif; ?>

                                                        <?php endif; ?>

                                                    </tr>

                                                </thead>

                                                
                                                <tbody class="">

                                                    <tr class="border-b">

                                                        <td
                                                            class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                            <strong>Prevista</strong>
                                                        </td>

                                                        <?php
                                                        $contMes = 1;
                                                        ?>

                                                        <?php $__currentLoopData = $this->indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                                                                <?php

                                                                if ($this->ano == date('Y')) {
                                                                    if ($evolucaoIndicador->num_mes <= $this->mesAnterior) {
                                                                        $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                                                        $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                                                    }
                                                                } else {
                                                                    $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                                                    $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                                                }

                                                                ?>

                                                                <?php if(!is_null($evolucaoIndicador->vlr_previsto)): ?>
                                                                    <td
                                                                        class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                                                                        <?php echo formatarValorConformeUnidadeMedida(
                                                                            $this->indicador->dsc_unidade_medida,
                                                                            'MYSQL',
                                                                            'PTBR',
                                                                            $evolucaoIndicador->vlr_previsto,
                                                                        ); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                                    </td>
                                                                <?php else: ?>
                                                                    <td
                                                                        class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                                                                        -</td>
                                                                <?php endif; ?>

                                                                <?php $contMes = $contMes + 1; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($this->indicador->bln_acumulado == 'Sim'): ?>
                                                            <td
                                                                class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                                                                <?php echo formatarValorConformeUnidadeMedida($this->indicador->dsc_unidade_medida, 'MYSQL', 'PTBR', $totalPrevisto); ?><?php $this->indicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                            </td>
                                                        <?php endif; ?>

                                                    </tr>

                                                    

                                                    
                                                    <tr class="border-b">

                                                        <td
                                                            class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                            <strong>Realizada</strong>
                                                        </td>

                                                        <?php $contMes = 1; ?>

                                                        <?php $__currentLoopData = $this->indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                                                                <?php if($this->ano == date('Y')): ?>
                                                                    <?php if($evolucaoIndicador->num_mes <= $this->mesAnterior): ?>
                                                                        <td
                                                                            class="text-sm text-gray-900 font-light whitespace-nowrap text-right">

                                                                            <?php if(!is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                                <div
                                                                                    class="bg-pink-800 text-white rounded-md px-5 py-1">
                                                                                    &nbsp;-
                                                                                </div>
                                                                            <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                                <div
                                                                                    class="bg-gray-500 text-white rounded-md px-5 py-1">
                                                                                    &nbsp;-
                                                                                </div>
                                                                            <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                                <?php echo formatarValorConformeUnidadeMedida(
                                                                                    $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                                    'MYSQL',
                                                                                    'PTBR',
                                                                                    $evolucaoIndicador->vlr_realizado,
                                                                                ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                                            <?php elseif(!is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                                <?php if(!is_null($evolucaoIndicador->vlr_realizado)): ?>
                                                                                    <?php $resultado = $this->obterResultadoComValorRealizadoEValorPrevisto($this->objetivoEstrategico->primeiroIndicador->dsc_tipo, $evolucaoIndicador->vlr_realizado, $evolucaoIndicador->vlr_previsto); ?>



                                                                                    <div
                                                                                        class="bg-<?php echo $resultado['grau_de_satisfacao']; ?>-500 text-<?php echo $resultado['color']; ?> rounded-md px-5 py-1">

                                                                                        <?php echo formatarValorConformeUnidadeMedida(
                                                                                            $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                                            'MYSQL',
                                                                                            'PTBR',
                                                                                            $evolucaoIndicador->vlr_realizado,
                                                                                        ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>

                                                                                    </div>
                                                                                <?php else: ?>
                                                                                <?php endif; ?>

                                                                        </td>
                                                                    <?php else: ?>
                                                                        <td
                                                                            class="text-sm text-gray-900 font-light whitespace-nowrap text-right">

                                                                            &nbsp;

                                                                        </td>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <td
                                                                        class="text-sm text-gray-900 font-light whitespace-nowrap text-right">

                                                                        &nbsp;

                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <td
                                                                    class="text-sm text-gray-900 font-light whitespace-nowrap text-right">

                                                                    <?php if(!is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                        <div
                                                                            class="bg-pink-800 text-white rounded-md px-5 py-1">
                                                                            &nbsp;-
                                                                        </div>
                                                                    <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                        <div
                                                                            class="bg-gray-500 text-white rounded-md px-5 py-1">
                                                                            &nbsp;-
                                                                        </div>
                                                                    <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                        <?php echo formatarValorConformeUnidadeMedida(
                                                                            $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                            'MYSQL',
                                                                            'PTBR',
                                                                            $evolucaoIndicador->vlr_realizado,
                                                                        ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                                    <?php elseif(!is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                        <?php if(!is_null($evolucaoIndicador->vlr_realizado)): ?>
                                                                            <?php $resultado = $this->obterResultadoComValorRealizadoEValorPrevisto($this->objetivoEstrategico->primeiroIndicador->dsc_tipo, $evolucaoIndicador->vlr_realizado, $evolucaoIndicador->vlr_previsto); ?>



                                                                            <div
                                                                                class="bg-<?php echo $resultado['grau_de_satisfacao']; ?>-500 text-<?php echo $resultado['color']; ?> rounded-md px-5 py-1">

                                                                                <?php echo formatarValorConformeUnidadeMedida(
                                                                                    $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                                    'MYSQL',
                                                                                    'PTBR',
                                                                                    $evolucaoIndicador->vlr_realizado,
                                                                                ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>

                                                                            </div>
                                                                        <?php else: ?>
                                                                </td>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
    <?php endif; ?>

    <?php $contMes = $contMes + 1; ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($this->objetivoEstrategico->primeiroIndicador->bln_acumulado == 'Sim'): ?>
        <?php $resultado = $this->obterResultadoComValorRealizadoEValorPrevisto($this->objetivoEstrategico->primeiroIndicador->dsc_tipo, $totalRealizado, $totalPrevisto);
        $this->totalRealizado = $totalRealizado; ?>

        <td class="text-sm text-gray-900 font-light whitespace-nowrap text-right">

            <div
                class="bg-<?php echo $resultado['grau_de_satisfacao']; ?>-<?php $resultado['grau_de_satisfacao'] != 'pink' ? print '500' : print '800'; ?> text-<?php echo $resultado['color']; ?> rounded-md px-5 py-1">

                <?php echo formatarValorConformeUnidadeMedida(
                    $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                    'MYSQL',
                    'PTBR',
                    $totalRealizado,
                ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>

            </div>

        </td>
    <?php endif; ?>

    </tr>
    

    
    <?php if(auth()->guard()->check()): ?>

        <?php

            foreach ($this->indicador->organizacoes as $organizacaoIndicador) {
                foreach ($this->getUserAuth->atuacaoOrganizacao as $value) {
                    if ($organizacaoIndicador->cod_organizacao == $value->cod_organizacao) {
                        $this->liberarAcessoParaAtualizar = true;
                        break;
                    }
                }
            }

        ?>

        
        <?php if($this->liberarAcessoParaAtualizar): ?>
            <tr class="border-b">

                <td class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                    <strong>Atualização</strong>
                </td>

                <?php $__currentLoopData = $this->indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                        <?php if(1 == 1): ?>
                            <?php if($evolucaoIndicador->num_mes <= $this->mesAnterior): ?>
                                <td class="text-sm text-gray-900 px-6 py-4 font-light whitespace-nowrap text-right">

                                    <span class="cursor-pointer" title="Incluir PDF para o mês de <?php echo mesNumeralParaExtensoCurto($evolucaoIndicador->num_mes); ?>"
                                        wire:click.prevent="abrirModalIncluirPdf('<?php echo $evolucaoIndicador->cod_evolucao_indicador; ?>')"><i
                                            class="fa-solid fa-file-pdf text-base text-red-600 "></i></span>
                                    &nbsp;&nbsp;
                                    <a href="javascript: void(0);" wire:click.prevent="editForm('<?php echo $evolucaoIndicador->cod_evolucao_indicador; ?>')"
                                        title="Editar a informação do mês de <?php echo mesNumeralParaExtensoCurto($evolucaoIndicador->num_mes); ?>"><i
                                            class="fas fa-edit text-base text-green-600"></i></a>

                                </td>
                            <?php else: ?>
                                <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">

                                    &nbsp;

                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($this->indicador->bln_acumulado == 'Sim'): ?>
                    <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                        &nbsp;</td>
                <?php endif; ?>

            </tr>
        <?php endif; ?>
        

    <?php endif; ?>
    

    </tbody>

    </table>
    

</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>



<div id="divConteudoTab3" style="display: none;">

    <p>Evolução mensal com as avaliações qualitativas e os arquivos anexos</p>

    <div class=" flex flex-wrap -mx-3 mb-6">

        <div class="w-full md:w-1/1 px-3 mb-6 md:mb-0 pt-3">

            <div class="border-b border-gray-200 shadow rounded-md">

                <?php
                    $totalPrevisto = 0;
                    $totalRealizado = 0;
                ?>

                <div class="flex flex-col">

                    <div class="overflow-x-auto">

                        <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">

                            <div class="overflow-x-auto">

                                
                                <table class="min-w-full">
                                    <thead class="border-b">

                                        <tr class="border-b">

                                            <th class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                <strong></strong>Mês
                                            </th>
                                            <th class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                <strong>Meta Prevista</strong>
                                            </th>
                                            <th class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                <strong>Meta Realizada</strong>
                                            </th>

                                            <th class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-left">
                                                A<strong>valiação qualitativa</strong></th>
                                            <th class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-left">
                                                <strong>Arquivos</strong>
                                            </th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php $__currentLoopData = $this->indicador->evolucaoIndicador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucaoIndicador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($evolucaoIndicador->num_ano == $this->ano): ?>
                                                <tr class="border-b">

                                                    <td
                                                        class="text-sm text-gray-900 px-6 py-4 whitespace-nowrap text-right">
                                                        <strong><?php echo mesNumeralParaExtensoCurto($evolucaoIndicador->num_mes); ?></strong>
                                                    </td>

                                                    <?php

                                                    if ($this->ano == date('Y')) {
                                                        if ($evolucaoIndicador->num_mes <= $this->mesAnterior) {
                                                            $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                                            $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                                        }
                                                    } else {
                                                        $totalPrevisto = $totalPrevisto + $evolucaoIndicador->vlr_previsto;

                                                        $totalRealizado = $totalRealizado + $evolucaoIndicador->vlr_realizado;
                                                    }

                                                    ?>

                                                    <?php if(!is_null($evolucaoIndicador->vlr_previsto)): ?>
                                                        <td
                                                            class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                                                            <?php echo formatarValorConformeUnidadeMedida(
                                                                $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                'MYSQL',
                                                                'PTBR',
                                                                $evolucaoIndicador->vlr_previsto,
                                                            ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?></td>
                                                    <?php else: ?>
                                                        <td
                                                            class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">
                                                            -</td>
                                                    <?php endif; ?>

                                                    <?php if($this->ano == date('Y')): ?>
                                                        <?php if($evolucaoIndicador->num_mes <= $this->mesAnterior): ?>
                                                            <td
                                                                class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">

                                                                <?php if(!is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                    <div
                                                                        class="bg-pink-800 text-white rounded-md px-5 py-1">
                                                                        &nbsp;-
                                                                    </div>
                                                                <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                    <div
                                                                        class="bg-gray-500 text-white rounded-md px-5 py-1">
                                                                        &nbsp;-
                                                                    </div>
                                                                <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                    <?php echo formatarValorConformeUnidadeMedida(
                                                                        $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                        'MYSQL',
                                                                        'PTBR',
                                                                        $evolucaoIndicador->vlr_realizado,
                                                                    ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                                <?php elseif(!is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                                    <?php if(!is_null($evolucaoIndicador->vlr_realizado)): ?>
                                                                        <?php $resultado = $this->obterResultadoComValorRealizadoEValorPrevisto($this->objetivoEstrategico->primeiroIndicador->dsc_tipo, $evolucaoIndicador->vlr_realizado, $evolucaoIndicador->vlr_previsto); ?>



                                                                        <div
                                                                            class="bg-<?php echo $resultado['grau_de_satisfacao']; ?>-500 text-<?php echo $resultado['color']; ?> rounded-md px-5 py-1">

                                                                            <?php echo formatarValorConformeUnidadeMedida(
                                                                                $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                                'MYSQL',
                                                                                'PTBR',
                                                                                $evolucaoIndicador->vlr_realizado,
                                                                            ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>

                                                                        </div>
                                                                    <?php else: ?>
                                                                    <?php endif; ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td
                                                                class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">

                                                                &nbsp;

                                                            </td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <td
                                                            class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">

                                                            &nbsp;

                                                        </td>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <td
                                                        class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-right">

                                                        <?php if(!is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                            <div class="bg-pink-800 text-white rounded-md px-5 py-1">
                                                                &nbsp;-
                                                            </div>
                                                        <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                            <div class="bg-gray-500 text-white rounded-md px-5 py-1">
                                                                &nbsp;-
                                                            </div>
                                                        <?php elseif(is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                            <?php echo formatarValorConformeUnidadeMedida(
                                                                $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                'MYSQL',
                                                                'PTBR',
                                                                $evolucaoIndicador->vlr_realizado,
                                                            ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>
                                                        <?php elseif(!is_null($evolucaoIndicador->vlr_previsto) && !is_null($evolucaoIndicador->bln_atualizado)): ?>
                                                            <?php if(!is_null($evolucaoIndicador->vlr_realizado)): ?>
                                                                <?php $resultado = $this->obterResultadoComValorRealizadoEValorPrevisto($this->objetivoEstrategico->primeiroIndicador->dsc_tipo, $evolucaoIndicador->vlr_realizado, $evolucaoIndicador->vlr_previsto); ?>



                                                                <div
                                                                    class="bg-<?php echo $resultado['grau_de_satisfacao']; ?>-500 text-<?php echo $resultado['color']; ?> rounded-md px-5 py-1">

                                                                    <?php echo formatarValorConformeUnidadeMedida(
                                                                        $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida,
                                                                        'MYSQL',
                                                                        'PTBR',
                                                                        $evolucaoIndicador->vlr_realizado,
                                                                    ); ?><?php $this->objetivoEstrategico->primeiroIndicador->dsc_unidade_medida === 'Porcentagem' ? print '%' : print ''; ?>

                                                                </div>
                                                            <?php else: ?>
                                                    </td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endif; ?>

                                        <td class="text-sm text-gray-900 font-light px-6 py-4 break-words text-justify"
                                            style="width: 45%!Important;">

                                            <?php echo nl2br($evolucaoIndicador->txt_avaliacao); ?>


                                        </td>

                                        <td
                                            class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap text-left">

                                            <?php $__currentLoopData = $evolucaoIndicador->arquivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arquivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="px-1 py-1 mt-2 mt-1 mb-2 pt-3 pb-3"
                                                    href="<?php echo url($this->anoSelecionado . '/evolucao-mensal-arquivo/' . $arquivo->cod_arquivo); ?>" target="_blank"><i
                                                        class="fas fa-file-pdf text-lg text-red-600"></i>
                                                    <?php echo $arquivo->txt_assunto; ?></a>
                                                <br />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </td>

                                        </tr>

                                        <?php $contMes = $contMes + 1; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                </table>
                                


                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>



<div class="w-full md:w-1/1 px-3 mt-2 mb-6 md:mb-0 pt-6">

    <p>Gráfico da Evolução Mensal</p>

    <canvas id="chart-<?php print $this->cod_indicador; ?>" style="width: 100%!Important; height: 333px!Important;"></canvas>

    <?php if($this->indicador->bln_acumulado === 'Não'): ?>
        <script type="text/javascript">
            new Chart(document.getElementById("chart-<?php print $this->cod_indicador; ?>"), {
                type: 'bar',
                data: {
                    labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
                    datasets: [{
                        label: "Meta prevista",
                        backgroundColor: "#3e95cd",
                        data: [<?php print $this->dataChartMetaPrevista; ?>]
                    }, {
                        label: "Meta realizada",
                        backgroundColor: "#8e5ea2",
                        data: [<?php print $this->dataChartMetaRealizada; ?>]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Teste'
                    },
                    scales: {
                        y: {
                            suggestedMin: 0,
                            suggestedMax: <?php print $this->metaAno; ?> + 5,
                        }
                    }
                }
            });
        </script>
    <?php endif; ?>

    <?php if($this->indicador->bln_acumulado === 'Sim'): ?>
        <script type="text/javascript">
            new Chart(document.getElementById("chart-<?php print $this->cod_indicador; ?>"), {
                type: 'line',
                data: {
                    labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
                    datasets: [{
                        data: [<?php print $this->dataChartMetaPrevista; ?>],
                        label: "Meta Prevista",
                        backgroundColor: "#3e95cd",
                        borderColor: "#3e95cd",
                        fill: false
                    }, {
                        data: [<?php print $this->dataChartMetaRealizada; ?>],
                        label: "Meta Realizada",
                        backgroundColor: "#9A3412",
                        borderColor: "#9A3412",
                        fill: false
                    }, {
                        label: "Linha de base",
                        backgroundColor: "#696969",
                        borderColor: "#696969",
                        data: [<?php print $this->dataChartLinhaBase; ?>]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Teste'
                    },
                    scales: {
                        y: {
                            suggestedMin: 0,
                            suggestedMax: <?php print $this->linhaBase; ?> + 50,
                        }
                    }
                }
            });
        </script>
    <?php endif; ?>

</div>


</div>
<?php else: ?>
<div class="w-full md:w-1/1 text-red-700 border-b-2 border-red-300 pt-3 pb-3 pl-1">

    Não há registro de indicadores para esse plano de ação

</div>

<?php endif; ?>

<div class="px-3 py-2 pt-2 pl-2 pr-2">
    &nbsp;
</div>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showModalInformacao']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'showModalInformacao']); ?>
    <form wire:submit.prevent="create" method="post">
         <?php $__env->slot('title', null, []); ?> 
            <strong>Importante</strong>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <?php echo $this->mensagemInformacao; ?>

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:loading.attr' => 'disabled','wire:click.prevent' => '$toggle(\'showModalInformacao\')','onclick' => 'javascript: location.reload();']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click.prevent' => '$toggle(\'showModalInformacao\')','onclick' => 'javascript: location.reload();']); ?>
                <?php echo e(__('Closer')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.geral-modal','data' => ['wire:model' => 'showModalIncluirPdf']]); ?>
<?php $component->withName('jet-geral-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'showModalIncluirPdf']); ?>
    <form method="POST" enctype="multipart/form-data" wire:submit.prevent="">
         <?php $__env->slot('title', null, []); ?> 
            <strong>Incluir PDF</strong>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <?php echo $this->formIncluirPdf; ?>


            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'pdf','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'pdf','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'txt_assunto','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'txt_assunto','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <div wire:loading wire:target="pdf">Uploading...</div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click.prevent' => '$toggle(\'showModalIncluirPdf\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => '$toggle(\'showModalIncluirPdf\')','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__('Closer')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click.prevent' => 'savePdf()','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'savePdf()','wire:loading.attr' => 'disabled']); ?>
                Salvar
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.geral-modal','data' => ['wire:model' => 'showModalResultadoEdicao']]); ?>
<?php $component->withName('jet-geral-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'showModalResultadoEdicao']); ?>
    <form wire:submit.prevent="create" method="post">
         <?php $__env->slot('title', null, []); ?> 
            <strong>Editar</strong>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <?php echo $this->mensagemResultadoEdicao; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'vlr_realizado','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'vlr_realizado','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click.prevent' => '$toggle(\'showModalResultadoEdicao\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => '$toggle(\'showModalResultadoEdicao\')','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__('Closer')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click.prevent' => 'create()','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'create()','wire:loading.attr' => 'disabled']); ?>
                Salvar
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'showModalDelete']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'showModalDelete']); ?>
     <?php $__env->slot('title', null, []); ?> 
        <strong>Excluir</strong>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <?php echo $this->mensagemDelete; ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('footer', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click.prevent' => '$toggle(\'showModalDelete\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => '$toggle(\'showModalDelete\')','wire:loading.attr' => 'disabled']); ?>
            <?php echo e(__('Closer')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click.prevent' => 'delete(\''.$this->cod_plano_de_acao.'\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'delete(\''.$this->cod_plano_de_acao.'\')','wire:loading.attr' => 'disabled']); ?>
            Sim, quero excluir
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.geral-modal','data' => ['wire:model' => 'showModalAudit']]); ?>
<?php $component->withName('jet-geral-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'showModalAudit']); ?>
     <?php $__env->slot('title', null, []); ?> 
        <strong>Ações Realizadas</strong>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <?php echo $this->mensagemDelete; ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('footer', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click.prevent' => '$toggle(\'showModalAudit\')','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => '$toggle(\'showModalAudit\')','wire:loading.attr' => 'disabled']); ?>
            <?php echo e(__('Closer')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</div>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/livewire/objetivo-estrategico/indicador/index.blade.php ENDPATH**/ ?>