<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Início ICON Brasil -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('img/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/favicon-32x32.png')); ?>" />
    <!-- Fim ICON Brasil -->

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <script src="https://cdn.tailwindcss.com"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>

    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery.mask.js')); ?>" type="text/javascript"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <?php echo \Livewire\Livewire::styles(); ?>


    <style type="text/css">
        .arrow-up {
            width: 0;
            height: 0;
            border-left: 75px solid transparent;
            border-right: 275px solid transparent;
            border-bottom: 17px solid rgba(238, 238, 238, var(--tw-bg-opacity));
            ;
        }
    </style>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>

<body class="font-sans antialiased">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="min-h-screen bg-white">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu', ['ano' => session('ano')])->html();
} elseif ($_instance->childHasBeenRendered('EQMU1cM')) {
    $componentId = $_instance->getRenderedChildComponentId('EQMU1cM');
    $componentTag = $_instance->getRenderedChildComponentTagName('EQMU1cM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EQMU1cM');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu', ['ano' => session('ano')]);
    $html = $response->html();
    $_instance->logRenderedChild('EQMU1cM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-white shadow-md">
                <div class="max-w-34xl mx-auto pt-2 pb-2 sm:pl-3 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- Page Content -->
        <main>
            <?php echo e($slot); ?>

        </main>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/layouts/app.blade.php ENDPATH**/ ?>