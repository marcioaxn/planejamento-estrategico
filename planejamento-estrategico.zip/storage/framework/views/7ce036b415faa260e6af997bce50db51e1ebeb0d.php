<div class="flex flex-wrap w-full text-base md:text-sm pt-0 pb-1 rounded-md border-1 border-gray-100"
    style="font-size: 0.91rem!Important;">

    <div class="w-full md:w-1/1 mt-2 pt-1 flex">

        <div class="bg-white rounded-lg overflow-hidden border-2 border-stone-200 flex-1 flex flex-col">

            <div
                class="bg-stone-50 text-stone-700 border-2  border-white border-b-stone-200 text-xl px-1 pt-1 pb-1 pl-3 pr-3">
                <strong>Entregas</strong>
            </div>

            <div class="bg-white text-justify pt-2 pb-3 pl-4 pr-3 flex-1">

                <?php
                    $contEntrega = 1;
                ?>

                <?php $__currentLoopData = $this->entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full md:w-1/1 mb-1 md:mb-1 pt-2">

                        <div class="flex flex-wrap w-full text-base md:text-sm pt-3 pb-3 rounded-md border-1 border-gray-100"
                            style="font-size: 0.91rem!Important;">

                            <div class="w-full md:w-1/1 mb-1 md:mb-1 pt-2">

                                <?php
                                    $grauSatisfacao = getGrauSatisfacaoEntrega($entrega->bln_status);
                                ?>

                                <div
                                    class="bg-gradient-to-r rounded from-<?php echo e($grauSatisfacao['cor']); ?>-500 text-xl text-<?php echo e($grauSatisfacao['font']); ?> p-1 pl-2 ">
                                    <?php echo e($this->perspectiva->num_nivel_hierarquico_apresentacao); ?>.<?php echo e($this->objetivoEstrategico->num_nivel_hierarquico_apresentacao); ?>.<?php echo e($this->collectionPlanoAcao->num_nivel_hierarquico_apresentacao); ?>.<?php echo e($entrega->num_nivel_hierarquico_apresentacao); ?>

                                </div>

                            </div>

                            <?php $__currentLoopData = $this->estruturaTableParaEditar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $column_name = $table->column_name;
                                ?>

                                <div class="w-full md:w-1/3 px-3 mb-2 md:mb-1 pt-3">

                                    <div class="col-span-6 sm:col-span-4">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'text-lg text-stone-500','value' => ''.e(nomeCampoNormalizado($column_name)).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-lg text-stone-500','value' => ''.e(nomeCampoNormalizado($column_name)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                        <?php if($this->liberarAcessoParaAtualizar): ?>
                                            <?php if($column_name != 'bln_status'): ?>
                                            <p class="text-xl">
                                                <?php echo e($entrega->$column_name); ?>

                                            </p>
                                            <?php else: ?>
                                                <?php
                                                    /** Incluir a verificação se está no prazo de início e fim da iniciativa */
                                                ?>

                                                <?php if(now()->between($this->collectionPlanoAcao->dte_inicio, $this->collectionPlanoAcao->dte_fim)): ?>
                                                    <?php echo Form::select('bln_status', $this->status, $entrega->$column_name, [
                                                        'class' =>
                                                            'border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 pt-0',
                                                        'style' => 'height: 40px !important; padding-left: 10px !important; width: 90% !important;',
                                                        'autocomplete' => 'off',
                                                        'required' => 'required',
                                                        'wire:change.prevent' => "setBlnStatus('{$entrega->cod_entrega}', \$event.target.value)",
                                                    ]); ?>

                                                    <p class="text-xs text-sky-600 pt-2">
                                                        Selecione o status atual e o sistema irá gravar automaticamente.
                                                    </p>
                                                <?php else: ?>
                                                    <p class="text-xl">
                                                        <?php echo e($entrega->$column_name); ?>

                                                    </p>
                                                    <p class="text-xs text-red-600 pt-2">
                                                        Você tem privilégio de gestão nesta Entrega, mas ela está fora
                                                        do período válido definido no Plano de Ação.
                                                    </p>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <p class="text-xl">
                                                <?php echo e($entrega->$column_name); ?>

                                            </p>
                                        <?php endif; ?>

                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <?php
                        $contEntrega++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

    </div>

</div>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/livewire/plano-de-acao/entregas/index.blade.php ENDPATH**/ ?>