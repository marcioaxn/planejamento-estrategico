<div class="mt-0 p-2 pt-0">

    <div class="flex flex-wrap w-full pt-1">

        <div class="w-full md:w-1/1 mt-2 mb-1 pt-1">

            <div class="rounded pt-1 pb-1 pl-3 pr-2 bg-blue-600 text-white text-lg items-center font-semibold text-lg "
                style="text-align: center!Important;">
                Objetivos Estratégicos | <?php echo e($this->pei->dsc_pei); ?>

            </div>

        </div>

        <div class="w-full md:w-1/1 pt-0 pb-0">

            <div class="col-span-6 sm:col-span-4">
                <?php echo Form::select('cod_organizacao', $this->organization, $this->cod_organizacao, [
                    'class' =>
                        'w-full pl-3 border-2 border-gray-300 border-opacity-25 h-11 font-semibold text-sm sm:text-base focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 text-blue-500 text-center pt-1 pb-1',
                    'style' => 'cursor: pointer;text-align: left !Important;',
                    'autocomplete' => 'off',
                    'wire:model' => 'cod_organizacao',
                    'onchange' => 'javascript: alterarUrlCodOrganizacao(this.value);',
                ]); ?>

            </div>

            <script>
                function alterarUrlCodOrganizacao(cod_organizacao) {

                    var url_antiga = window.location.pathname;

                    var cod_organizacao_antigo = window.livewire.find('<?php echo e($_instance->id); ?>').cod_organizacao;

                    var nova_url = url_antiga.replace(cod_organizacao_antigo, cod_organizacao);

                    var origin = window.location.origin;

                    window.location = origin + nova_url;

                    // window.history.pushState({}, 'Title', nova_url);


                }
            </script>

        </div>

    </div>

    <div class="flex flex-wrap w-full text-lg md:text-sm p-1 pt-2 rounded-md border-1 border-gray-100 mb-1">

        <div class="w-full md:w-1/12 border-b-2 text-lg border-gray-100 pt-1 pb-2 pl-1">
            Perspectiva:
        </div>

        <div class="w-full md:w-11/12 text-lg border-b-2 border-gray-100 pt-1 pb-2 pl-1">
            <strong><?php echo $this->perspectiva->num_nivel_hierarquico_apresentacao; ?>. <?php echo $this->perspectiva->dsc_perspectiva; ?></strong>
        </div>

    </div>

    <div class="rounded-t-lg pt-1 pb-1 pl-3 pr-2 bg-blue-600 text-white text-xl font-bold text-lg ">
        Objetivo Estratégico <span class="text-yellow-300"><?php echo e($this->perspectiva->num_nivel_hierarquico_apresentacao); ?>.
            <?php echo e($this->objetivoEstrategico->num_nivel_hierarquico_apresentacao); ?>.</span>
    </div>

    <div
        class="w-full p-4 bg-white border border-gray-200 rounded-b-lg shadow sm:p-3 dark:bg-gray-800 dark:border-gray-700">

        <p class="mb-0">
            <?php echo Form::select('cod_objetivo_estrategico', $this->objetivoEstragicoPluck, null, [
                'class' =>
                    'w-full text-left pl-1 border-0 border-white border-opacity-25 font-semibold text-lg focus:border-indigo-300 focus:ring focus:ring-gray-50 focus:ring-opacity-50 h-7 text-black rounded-md text-left cursor-pointer whitespace-normal break-words',
                'autocomplete' => 'off',
                'required' => 'required',
                'wire:model' => 'cod_objetivo_estrategico',
                'onchange' => 'javascript: alterarUrlCodObjetivoEstrategico(this.value);',
            ]); ?>

        </p>
    </div>

    <div class="flex flex-wrap md:flex-nowrap w-full pt-1 gap-2">

        <div class="w-full md:w-1/2 mt-2 pt-1 flex">

            <div class="bg-white rounded-lg overflow-hidden border-2 border-green-700 flex-1 flex flex-col">

                <div class="bg-green-700 text-white text-xl px-1 pt-1 pb-1 pl-3 pr-3">
                    <strong>Descrição</strong>
                </div>

                <div class="bg-green-50 text-justify pt-2 pb-3 pl-3 pr-3 flex-1">
                    <?php echo e($this->objetivoEstrategico->dsc_objetivo_estrategico); ?>

                </div>

            </div>

        </div>

        <div class="w-full md:w-1/2 mt-2 pt-1 flex">

            <div class="bg-white rounded-lg overflow-hidden border-2 border-red-600 flex-1 flex flex-col">

                <div class="bg-red-500 text-white text-xl px-1 pt-1 pb-1 pl-3 pr-3">
                    <strong>Futuro Almejado</strong>
                </div>

                <div class="bg-red-50 text-justify pt-2 pb-3 pl-4 pr-3 flex-1">
                    <ul class="list-disc pl-3">
                        <?php $__currentLoopData = $this->objetivoEstrategico->fututosAlmejados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fututosAlmejado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($fututosAlmejado->dsc_futuro_almejado); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>

        </div>

    </div>

    <?php echo $__env->make('livewire.plano-de-acao.navbar-indicador-objetivo-estrategico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mb-4 p-2">

        <div>

            <p class="pb-2">Legenda do Grau de satisfação:</p>

        </div>

        <div
            class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-5 2xl:grid-cols-5 gap-2 mt-0">

            <?php echo $this->grau_satisfacao; ?>


        </div>

    </div>

</div>
<?php /**PATH E:\xampp\htdocs\planejamento-estrategico\resources\views/livewire/indicador-objetivo-estrategico-livewire.blade.php ENDPATH**/ ?>