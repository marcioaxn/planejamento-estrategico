<div>
    {{-- A good traveler has no fixed plans and is not intent upon arriving. --}}
</div>
